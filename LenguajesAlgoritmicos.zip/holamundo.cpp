#include <iostream>
#include <conio.h>
#include <math.h>
//programa en c++ para probar
//Hola Mundo
using namespace std;

main()
{
    int n,x,z;
    double y;
    x=0;
    y=0;
    z=0;
    n=0;
    cout <<"Ingrese el numero maximo\n\n";
    cout << "Numero Maximo: ";
	cin >> n;
    cout << "\n1\n2\n";
	for (x=2;x<=n;x++) {
		y=0;
		z=2;
		//cout<<x;
		while (z!=x){
			y=z%x;
			//cout<<n+z;
			if (z==n-1){
				if (y!=0){
				cout<<x;
				//cout<<"true";
				cout<<"\n";
				}
			}
			z++;
			}
		}
	}
