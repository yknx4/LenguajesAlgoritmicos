#include <iostream>
#include <conio.h>
#include <math.h>
//programa en c++ para probar
//Hola Mundo
using namespace std;

int main()
{
	cout<<getch();
}
