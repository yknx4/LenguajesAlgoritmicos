#include <iostream>

using namespace std;

int i;

int main(){
	i=1;
	do{
		cout<<i<<"\n";
		i++;
	}while(i<11);
}
