#include <iostream>
#include <conio.h>
#include <string>
using namespace std;

int main()
{

    while ( true )
    {
		cout<<cin.get();
        }
     
}
