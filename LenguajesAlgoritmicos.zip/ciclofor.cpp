#include <iostream>

using namespace std;

int i;

int main(){
	for(i=1;i<11;i++){
		cout<<i<<"\n";
	}
}
