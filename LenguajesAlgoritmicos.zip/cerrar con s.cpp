#include <iostream>
#include <conio.h>
using namespace std;
int main(){
	char opc;
	opc='s';
	do{
		cout<<"Escriba un caracter:\n";
		cin>>opc;
	}while (opc!='s');
	
	
}
