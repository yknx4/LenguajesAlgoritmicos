#include <iostream>

using namespace std;

int i;

int main(){
	i=1;
	while(i<11){
		cout<<i<<"\n";
		i++;
	}
}
