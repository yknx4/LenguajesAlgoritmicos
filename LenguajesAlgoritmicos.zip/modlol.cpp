#include <iostream>
int main(){
	std::cout<<11%3;
}
