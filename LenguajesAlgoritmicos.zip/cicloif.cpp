#include <iostream>

using namespace std;

int i;

int main(){
	i=1;
	inicio:
	if(i<11){
		cout<<i<<"\n";
		i++;
		goto inicio;
	}
}
