#include <iostream>
#include <math.h>

using namespace std;

main()
{	
	cout << 7/2 << "\n";
	cout << 7%2<< "\n";
	cout << 12/3 << "\n";
	cout << 12%3 << "\n";
	//cout << "La suma es: " << a+b << "\n\n";
	//cout << a+b;
	//cout << "\n\n";	
	//cout << "Fin de la suma";
}

