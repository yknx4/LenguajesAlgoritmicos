//#define Debug
#ifdef Debug
#include <windows.h>
#include <iostream>
#include <conio.h>
#include <math.h>
#include <string>
using namespace std;
int main(){
#endif	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
#ifdef Debug
}
#endif
