#include <iostream>

using namespace std;

main()
{
	int a,b,i;
	for  (i=1;i<=3;i++){	
		cout << "Inserte a\n";
		cin >> a;
		cout << "Inserte b\n";
		cin >>b;
		cout << "La suma es: " << a+b << "\n\n";
		//cout << a+b;
		//cout << "\n\n";
	}
	cout << "Fin de la suma";
}

