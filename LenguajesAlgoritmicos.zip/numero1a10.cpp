#include <iostream>
#include <conio.h>
#include <math.h>

using namespace std;

int main(){
	int x;
	for (x=0;x<11;x++){
		cout<<x<<"\n";
	}
}
